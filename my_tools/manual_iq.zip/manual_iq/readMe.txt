You simply need to put files, especially csv files in their respective folders, and leave the folders you do not need blank.
